
<?php $__env->startSection('content'); ?>
    <div class="height-100">
        <div class="row">
            <h4 class="mb-4 mt-4">Ubah Data Peserta</h4>
        </div>
        <div class="card">
            <div class="card-body">
                <form class="row g-3" action="<?php echo e(route('internalisasis.update', $internalisasi->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <div class="col-md-12">
                        <label for="name" class="form-label">Masukkan Nama</label>
                        <input type="text" class="form-control" id="name" name="name" value="<?php echo e($internalisasi->name); ?>">
                    </div>
                    <div class="col-md-6">
                        <label for="nrp" class="form-label">NRP</label>
                        <input type="number" class="form-control" id="nrp" name="nrp" value="<?php echo e($internalisasi->nrp); ?>">
                    </div>
                    <div class="col-md-6">
                        <label for="department" class="form-label">Departemen</label>
                        <select id="department" class="form-select" name="department">
                            <option selected>Pilih departemen</option>
                            <option value="Fisika" <?php echo e($internalisasi->department == 'Fisika' ? 'selected' : ''); ?>>Fisika</option>
                            <option value="Matematika <?php echo e($internalisasi->department == 'Matematika' ? 'selected' : ''); ?>">Matematika</option>
                            <option value="Statistika <?php echo e($internalisasi->department == 'Statistika' ? 'selected' : ''); ?>">Statistika</option>
                            <option value="Kimia <?php echo e($internalisasi->department == 'Kimia' ? 'selected' : ''); ?>">Kimia</option>
                            <option value="Biologi" <?php echo e($internalisasi->department == 'Biologi' ? 'selected' : ''); ?>>Biologi</option>
                            <option value="Aktuaria" <?php echo e($internalisasi->department == 'Aktuaria' ? 'selected' : ''); ?>>Aktuaria</option>
                            <option value="Teknik Mesin" <?php echo e($internalisasi->department == 'Teknik Mesin' ? 'selected' : ''); ?>>Teknik Mesin</option>
                            <option value="Teknik Kimia" <?php echo e($internalisasi->department == 'Teknik Kimia' ? 'selected' : ''); ?>>Teknik Kimia</option>
                            <option value="Teknik Pangan" <?php echo e($internalisasi->department == 'Teknik Pangan' ? 'selected' : ''); ?>>Teknik Pangan</option>
                            <option value="Teknik Fisika" <?php echo e($internalisasi->department == 'Teknik Fisika' ? 'selected' : ''); ?>>Teknik Fisika</option>
                            <option value="Teknik Industri" <?php echo e($internalisasi->department == 'Teknik Industri' ? 'selected' : ''); ?>>Teknik Industri</option>
                            <option value="Teknik Material" <?php echo e($internalisasi->department == 'Teknik Material' ? 'selected' : ''); ?>>Teknik Material</option>
                            <option value="Teknik Sipil" <?php echo e($internalisasi->department == 'Teknik Sipil' ? 'selected' : ''); ?>>Teknik Sipil</option>
                            <option value="Arsitektur" <?php echo e($internalisasi->department == 'Arsitektur' ? 'selected' : ''); ?>>Arsitektur</option>
                            <option value="Teknik Lingkungan" <?php echo e($internalisasi->department == 'Teknik Lingkungan' ? 'selected' : ''); ?>>Teknik Lingkungan</option>
                            <option value="Perencanaan Wilayah & Kota" <?php echo e($internalisasi->department == 'Perencanaan Wilayah & Kota' ? 'selected' : ''); ?>>Perencanaan Wilayah & Kota</option>
                            <option value="Teknik Geomatika" <?php echo e($internalisasi->department == 'Teknik Geomatika' ? 'selected' : ''); ?>>Teknik Geomatika</option>
                            <option value="Teknik Geofisika" <?php echo e($internalisasi->department == 'Teknik Geofisika' ? 'selected' : ''); ?>>Teknik Geofisika</option>
                            <option value="Teknik Perkapalan" <?php echo e($internalisasi->department == 'Teknik Perkapalan' ? 'selected' : ''); ?>>Teknik Perkapalan</option>
                            <option value="Sistem Perkapalan" <?php echo e($internalisasi->department == 'Sistem Perkapalan' ? 'selected' : ''); ?>>Sistem Perkapalan</option>
                            <option value="Teknik Kelautan" <?php echo e($internalisasi->department == 'Teknik Kelautan' ? 'selected' : ''); ?>>Teknik Kelautan</option>
                            <option value="Transportasi Laut" <?php echo e($internalisasi->department == 'Transportassi Laut' ? 'selected' : ''); ?>>Teknik Transportasi Laut</option>
                            <option value="Teknik Elektro" <?php echo e($internalisasi->department == 'Teknik Elektro' ? 'selected' : ''); ?>>Teknik Elektro</option>
                            <option value="Teknik Biomedik" <?php echo e($internalisasi->department == 'Teknik Biomedik' ? 'selected' : ''); ?>>Teknik Biomedik</option>
                            <option value="Teknik Komputer" <?php echo e($internalisasi->department == 'Teknik Komputer' ? 'selected' : ''); ?>>Teknik Komputer</option>
                            <option value="Teknik Informatika" <?php echo e($internalisasi->department == 'Teknik Informatika' ? 'selected' : ''); ?>>Teknik Informatika</option>
                            <option value="Sistem Informasi" <?php echo e($internalisasi->department == 'Sistem Informasi' ? 'selected' : ''); ?>>Sistem Informasi</option>
                            <option value="Teknologi Informasi" <?php echo e($internalisasi->department == 'Teknologi Informasi' ? 'selected' : ''); ?>>Teknologi Informasi</option>
                            <option value="Desain Produk" <?php echo e($internalisasi->department == 'Desain Produk' ? 'selected' : ''); ?>>Desain Produk</option>
                            <option value="Desain Interior" <?php echo e($internalisasi->department == 'Desain Interior' ? 'selected' : ''); ?>>Desain Interior</option>
                            <option value="Desain Komunikasi Visual" <?php echo e($internalisasi->department == 'Desain Komunikasi Visual' ? 'selected' : ''); ?>>Desain Komunikasi Visual</option>
                            <option value="Manajemen Bisnis" <?php echo e($internalisasi->department == 'Manajemen Bisnis' ? 'selected' : ''); ?>>Manajemen Bisnis</option>
                            <option value="Studi Pembangunan" <?php echo e($internalisasi->department == 'Studi Pembangunan' ? 'selected' : ''); ?>>Studi Pembangunan</option>
                            <option value="Statistika Bisnis" <?php echo e($internalisasi->department == 'Statistika Bisnis' ? 'selected' : ''); ?>>Statistika Bisnis</option>
                            <option value="Teknik Manufaktur" <?php echo e($internalisasi->department == 'Teknik Manufaktur' ? 'selected' : ''); ?>>Teknik Manufaktur</option>
                            <option value="Teknik Konversi Energi" <?php echo e($internalisasi->department == 'Teknik Konversi Energi' ? 'selected' : ''); ?>>Teknik Konversi Energi</option>
                            <option value="Teknik Otomasi" <?php echo e($internalisasi->department == 'Teknik Otomasi' ? 'selected' : ''); ?>>Teknik Otomasi</option>
                            <option value="Teknik Kimia Industri" <?php echo e($internalisasi->department == 'Teknik Kimia Industri' ? 'selected' : ''); ?>>Teknik Kimia Industri</option>
                            <option value="Teknik Instrumentasi" <?php echo e($internalisasi->department == 'Teknik Instrumentasi' ? 'selected' : ''); ?>>Teknik Instrumentasi</option>
                        </select>
                    </div>
                    <div class="col-md-6">
                        <label for="division" class="form-label">Divisi</label>
                        <select id="division" class="form-select" name="division">
                            <option selected>Pilih divisi</option>
                            <option value="TECHNICAL" <?php echo e($internalisasi->division == 'TECHNICAL' ? 'selected' : ''); ?>>TECHNICAL</option>
                            <option value="STRD" <?php echo e($internalisasi->division == 'STRD' ? 'selected' : ''); ?>>STRD</option>
                            <option value="OF" <?php echo e($internalisasi->division == 'OF' ? 'selected' : ''); ?>>OF</option>
                            <option value="COMM" <?php echo e($internalisasi->division == 'COMM' ? 'selected' : ''); ?>>COMM</option>
                        </select>
                    </div>
                    <div class="col-md-6">
                        <label for="subdivision" class="form-label">Sub divisi</label>
                        <select id="subdivision" class="form-select" name="subdivision">
                            <option selected>Pilih subdivisi</option>
                            <option value="Vehicle Dynamics" <?php echo e($internalisasi->subdivision == 'Vehicle Dynamics' ? 'selected' : ''); ?>>Vehicle Dynamics</option>
                            <option value="Electronical & Powertrain System" <?php echo e($internalisasi->subdivision == 'Electronical & Powertrain System' ? 'selected' : ''); ?>>Electronical & Powertrain System</option>
                            <option value="Body & Frame" <?php echo e($internalisasi->subdivision == 'Body & Frame' ? 'selected' : ''); ?>>Body & Frame</option>
                            <option value="Science & Technology Research Development" <?php echo e($internalisasi->subdivision == 'Science & Technology Research Development' ? 'selected' : ''); ?>>Science & Technology Research
                                Development</option>
                            <option value="Sponsorship & Relation" <?php echo e($internalisasi->subdivision == 'Sponsorship & Relation' ? 'selected' : ''); ?>>Sponsorship & Relation</option>
                            <option value="Administration & Accommodation" <?php echo e($internalisasi->subdivision == 'Administration & Accommodation' ? 'selected' : ''); ?>>Administration & Accommodation</option>
                            <option value="Creative" <?php echo e($internalisasi->subdivision == 'Creative' ? 'selected' : ''); ?>>Creative</option>
                            <option value="Content Strategist" <?php echo e($internalisasi->subdivision == 'Content Strategist' ? 'selected' : ''); ?>>Content Strategist</option>
                            <option value="Events and Media Relation" <?php echo e($internalisasi->subdivision == 'Events and Media Relation' ? 'selected' : ''); ?>>Events and Media Relation</option>
                            <option value="Web Developer" <?php echo e($internalisasi->subdivision == 'Web Developer' ? 'selected' : ''); ?>>Web Developer</option>
                        </select>
                    </div>
                    <div class="col-12">
                        <a class="btn btn-info" href="<?php echo e(route('internalisasis.index')); ?>">Kembali</a>
                        <button type="submit" class="btn btn-primary">Simpan</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fpantasenabackup\resources\views/admin/internalisasis/edit.blade.php ENDPATH**/ ?>