
<?php $__env->startSection('content'); ?>
    <div class="height-100">
        <div class="row">
            <h4 class="mb-4 mt-4">List Peserta Internalisasi</h4>
        </div>
        <div class="row">
            <table class="table table-striped table-hover">
                <thead class="table-dark">
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Nama</th>
                        <th scope="col">NRP</th>
                        <th scope="col">Subdivisi</th>
                        <th scope="col">Waktu</th>
                        <th scope="col">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $internalisasis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $internalisasi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e(++$i); ?></td>
                            <td><?php echo e($internalisasi->name); ?></td>
                            <td><?php echo e($internalisasi->nrp); ?></td>
                            <td><?php echo e($internalisasi->subdivision); ?></td>
                            <td><?php echo e($internalisasi->time); ?></td>
                            <td>
                                <form onsubmit="return confirm('Apakah Anda Yakin ?');" action="<?php echo e(route('internalisasis.destroy', $internalisasi->id)); ?>" method="POST">
                                    <a class="btn btn-info"
                                        href="<?php echo e(route('internalisasis.show', $internalisasi->id)); ?>">Show</a>
                                    <a class="btn btn-primary"
                                        href="<?php echo e(route('internalisasis.edit', $internalisasi->id)); ?>">Edit</a>
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-danger">Delete</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="alert alert-danger">
                            Data List belum Tersedia.
                        </div>
                    <?php endif; ?>
                </tbody>
                <tfoot class="table-dark">
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Nama</th>
                        <th scope="col">NRP</th>
                        <th scope="col">subdivisi</th>
                        <th scope="col">Waktu</th>
                        <th scope="col">Action</th>
                    </tr>
                </tfoot>
            </table>
            <?php echo e($internalisasis->links()); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fpantasenabackup\resources\views/admin/internalisasis/index.blade.php ENDPATH**/ ?>