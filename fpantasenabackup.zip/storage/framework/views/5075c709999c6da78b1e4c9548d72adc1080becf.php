
<?php $__env->startSection('content'); ?>
    <div class="height-100">
        <div class="row">
            <h4 class="mb-4 mt-4">Data Peserta</h4>
        </div>
        <div class="card">
            <div class="card-body">
                <div class="col-md-12">
                    <b><label for="name" class="form-label">Nama : </label></b>
                    <?php echo e($internalisasi->name); ?>

                </div>
                <div class="col-md-6">
                    <b><label for="nrp" class="form-label">NRP : </label></b>
                    <?php echo e($internalisasi->nrp); ?>

                </div>
                <div class="col-md-6">
                    <b><label for="department" class="form-label">Departemen : </label></b>
                    <?php echo e($internalisasi->department); ?>

                </div>
                <div class="col-md-6">
                    <b><label for="division" class="form-label">Divisi : </label></b>
                    <?php echo e($internalisasi->division); ?>

                </div>
                <div class="col-md-6">
                    <b><label for="subdivision" class="form-label">Sub divisi : </label></b>
                    <?php echo e($internalisasi->subdivision); ?>

                </div>
                <div class="col-md-3">
                    <b><label for="time" class="form-label">Waktu Kehadiran : </label></b>
                    <?php echo e($internalisasi->time); ?>

                </div>
            </div>
        </div>
        <a class="btn btn-info" href="<?php echo e(route('internalisasis.index')); ?>">Kembali</a>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fpantasenabackup\resources\views/admin/internalisasis/show.blade.php ENDPATH**/ ?>